var searchData=
[
  ['data0_19',['data0',['../liaison__serie_8ino.html#a2e10275ff114f8a9884d107667675076',1,'liaison_serie.ino']]],
  ['data3_20',['data3',['../liaison__serie_8ino.html#a5345a736c8bf68d727efd2103e163569',1,'liaison_serie.ino']]]
];
